import '@fontsource/acme'
import '@fontsource/fira-mono'
import '@app/shared/ui/globals.css'
import { Provider } from 'effector-react/scope'
import type { NextPage } from 'next'
import type { AppProps } from 'next/app'
import { withEffector } from 'nextjs-effector'
import type { ReactElement, ReactNode } from 'react'
import { MediaContextProvider } from '@app/shared/ui/media'
// import { MainErrorBoundary } from '@/shared/ui';

type LayoutGetter = (page: ReactElement) => ReactNode

type NextPageWithLayout = NextPage & {
  getLayout?: LayoutGetter
}

type AppPropsWithLayout = AppProps & {
  Component: NextPageWithLayout
}

const getFallbackLayout: LayoutGetter = (page) => page

const WrappedApp = ({ Component, pageProps }: AppPropsWithLayout) => {
  const getLayout = Component.getLayout ?? getFallbackLayout

  return (
    // <MainErrorBoundary>
    <MediaContextProvider>
      {getLayout(<Component {...pageProps} />)}
    </MediaContextProvider>
    // </MainErrorBoundary>
  )
}

export default withEffector(WrappedApp, { Provider })
