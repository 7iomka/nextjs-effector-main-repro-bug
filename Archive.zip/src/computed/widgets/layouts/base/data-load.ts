import { createGIPFactory } from 'nextjs-effector'

export const createBaseGetInitialProps = createGIPFactory()
