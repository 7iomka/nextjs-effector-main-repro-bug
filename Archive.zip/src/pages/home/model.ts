import { createEvent } from 'effector'

export const pageStarted = createEvent()
